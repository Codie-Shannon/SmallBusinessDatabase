-- Maps Table --
-- ======================================================================== --
-- Add Record to Table --
INSERT INTO Maps (MapImg, Deliverables)
VALUES ('https://github.com/CodieShannon/OvatoDistributions/blob/main/route_template_2.jpg?raw=true', 195);

-- Read One Record From Table Based on MapsID --
SELECT * FROM Maps WHERE MapsID = 9;

-- Record Records From Table Where The Deliverables Values Are Above 175 --
SELECT * FROM Maps WHERE Deliverables > 175;

-- Read All Records in Table --
SELECT * FROM Maps;

-- Update Record in Table --
UPDATE Maps
SET Deliverables = 182
WHERE MapsID = 9;

-- Delete Record From Table --
DELETE FROM Maps
WHERE MapsID = 9;
GO

-- Procedurally Add Record to Table --
CREATE PROCEDURE insert_map (@MapImg NVARCHAR(255), @Deliverables int)
AS
INSERT INTO Maps
VALUES (@MapImg, @Deliverables);
GO

EXECUTE insert_map 'https://github.com/CodieShannon/OvatoDistributions/blob/main/route_template_2.jpg?raw=true', 168;

SELECT * FROM Maps;
GO

DROP PROCEDURE insert_map;
GO


-- Contacts Table --
-- ======================================================================== --
-- Add Record to Table --
INSERT INTO Contacts (FirstName, LastName, Phone, Email, Street, City)
VALUES ('Billy', 'Bob', '0220218954', 'billy.bob100@outlook.com', '297 Bridge St', 'Whakatane');

-- Read One Record From Table Based On FirstName and LastName --
SELECT * FROM Contacts WHERE FirstName = 'Billy' AND LastName = 'Bob';

-- Read All Records From Table Where the FirstName Values are Edward --
SELECT * FROM Contacts WHERE FirstName = 'Edward';

-- Read All Records in Table --
SELECT * FROM Contacts;

-- Update Record in Table --
UPDATE Contacts
SET Street = '101 Arawa Rd'
WHERE FirstName = 'Billy' AND LastName = 'Bob';

-- Delete Record From Table --
DELETE FROM Contacts
WHERE FirstName = 'Billy' AND LastName = 'Bob';
GO

-- Procedurally Add Record to Table --
CREATE PROCEDURE insert_contact (@FirstName NVARCHAR(100), @LastName NVARCHAR(100), @Phone VARCHAR(50), @Email NVARCHAR(255), @Street VARCHAR(100), @City VARCHAR(100), @isAvailable BIT, @DateAvail DATETIME)
AS
INSERT INTO Contacts
VALUES (@FirstName, @LastName, @Phone, @Email, @Street, @City, @isAvailable, @DateAvail);
GO

EXECUTE insert_contact 'Billy', 'Bob', '0220218954', 'billy.bob100@outlook.com', '297 Bridge St', 'Whakatane', 1, null;

SELECT * FROM Contacts;
GO

DROP PROCEDURE insert_contact;
GO


-- Deliverers Table --
-- ======================================================================== --
-- Add Record to Table --
INSERT INTO Deliverers (MapsID, ContactsID)
VALUES (4, 5);

-- Read One Record From Table Based On MapsID and ContactsID --
SELECT * FROM Deliverers WHERE MapsID = 4 AND ContactsID = 5;

-- Read Records From Table Where the Deliverers Values are Above 5 --
SELECT * FROM Deliverers WHERE MapsID > 5;

-- Read All Records From Table --
SELECT * FROM Deliverers;

-- Update Record in Table --
UPDATE Deliverers
SET MapsID = 7
WHERE MapsID = 4 AND ContactsID = 5;

-- Delete Record From Table --
DELETE FROM Deliverers
WHERE MapsID = 7 AND ContactsID = 5;
GO

-- Procedurally Add Record to Table --
CREATE PROCEDURE insert_deliverer (@MapsID int, @ContactsID int)
AS
INSERT INTO Deliverers
VALUES (@MapsID, @ContactsID);
GO

EXECUTE insert_deliverer 4, 5;

SELECT * FROM Deliverers;
GO

DROP PROCEDURE insert_deliverer;
GO


-- PamphletTypes Table --
-- ======================================================================== --
-- Add Record to Table --
INSERT INTO PamphletTypes (PamType, BundleQuantity)
VALUES ('Masport', 400);

-- Read All Records in Table --
SELECT * FROM PamphletTypes;

-- Update Record in Table --
UPDATE PamphletTypes
SET BundleQuantity = 800
WHERE PamType = 'Masport';

-- Delete Record in Table --
DELETE FROM PamphletTypes
WHERE PamType = 'Masport';
GO

-- Procedurally Add Record to Table --
CREATE PROCEDURE insert_pamphlet (@PamType VARCHAR(150), @BundleQuantity int)
AS
INSERT INTO PamphletTypes
VALUES (@PamType, @BundleQuantity);
GO

EXECUTE insert_pamphlet 'Masport', 400;

SELECT * FROM PamphletTypes;
GO

DROP PROCEDURE insert_pamphlet;
GO


-- Deliveries Table --
-- ======================================================================== --
-- Add Record to Table --
INSERT INTO Deliveries(DeliverersID, PamType1, PamType2, PamType3, PamType4, PamType5, PamType6)
VALUES (14, 'Supercheap Auto', 'Repco', null, null, null, null);

-- Read One Record From Table Based On DeliverersID --
SELECT * FROM Deliveries WHERE DeliverersID = 14;

-- Read Records From Table Where the PamType2 Values are Repco --
SELECT * FROM Deliveries WHERE PamType2 = 'Repco';

-- Read All Records From Table --
SELECT * FROM Deliveries;

-- Update Record in Table --
UPDATE Deliveries
SET PamType3 = 'Farmers'
WHERE DeliverersID = 14;

-- Delete Record From Table --
DELETE FROM Deliveries
WHERE DeliverersID = 14;
GO

-- Procedurally Add Record to Table --
CREATE PROCEDURE insert_delivery (@DeliverersID int, @PamType1 VARCHAR(150), @PamType2 VARCHAR(150), @PamType3 VARCHAR(150), @PamType4 VARCHAR(150), @PamType5 VARCHAR(150), @PamType6 VARCHAR(150), @isDelivered BIT, @DelDate DateTime)
AS
INSERT INTO Deliveries
VALUES (@DeliverersID, @PamType1, @PamType2, @PamType3, @PamType4, @PamType5, @PamType6, @isDelivered, @DelDate);
GO

EXECUTE insert_delivery 14, 'Supercheap Auto', 'Repco', null, null, null, null, 0, null;

SELECT * FROM Deliveries;
GO

DROP PROCEDURE insert_delivery;
GO